using CodeExpress.v1_0.Secs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeExpress.CmdSecsSample
{
    public class MacSecsMsgBase
    {
        public CxHsmsMessage SecsMessageInst = new CxHsmsMessage();

        #region Secs Header Access

        public byte StreamId { get { return this.SecsMessageInst.header.StreamId; } set { this.SecsMessageInst.header.StreamId = value; } }
        public byte FunctionId { get { return this.SecsMessageInst.header.FunctionId; } set { this.SecsMessageInst.header.FunctionId = value; } }
        public byte SType { get { return this.SecsMessageInst.header.SType; } set { this.SecsMessageInst.header.SType = value; } }

        #endregion

        public MacSecsMsgBase() { }
        public MacSecsMsgBase(CxHsmsMessage msg) { this.SecsMessageInst = msg; }

        public T As<T>() where T : MacSecsMsgBase { return this as T; }
        public T To<T>() where T : MacSecsMsgBase, new() { return new T() { SecsMessageInst = this.SecsMessageInst }; }

        public string ToSml() { return this.SecsMessageInst.ToSml(); }





        #region Operator

        public static implicit operator CxHsmsMessage(MacSecsMsgBase prescribedSecs) { return prescribedSecs.SecsMessageInst; }
        public static implicit operator MacSecsMsgBase(CxHsmsMessage prescribedSecs) { return new MacSecsMsgBase(prescribedSecs); }

        #endregion

    }
}
