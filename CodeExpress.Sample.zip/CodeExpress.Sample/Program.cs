﻿using CodeExpress.v1_0.Secs;
using CToolkit.v1_1.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeExpress.Sample
{
    class Program
    {
        static void Main(string[] args)
        {
            HsmsConnectorTestPassive();
        }


        public static void HsmsConnectorTestPassive()
        {
            using (var hsmsConnector = new CxHsmsConnector())
            {
                hsmsConnector.EhReceiveData += delegate (Object sen, CxHsmsConnectorRcvDataEventArg ea)
                {

                    var myMsg = ea.msg;


                    Console.WriteLine("S{0}F{1}", myMsg.header.StreamId, myMsg.header.FunctionId);
                    Console.WriteLine("SType= {0}", myMsg.header.SType);

                    switch (myMsg.header.SType)
                    {
                        case 1:
                            hsmsConnector.Send(CxHsmsMessage.CtrlMsg_SelectRsp(0));
                            return;
                        case 5:
                            hsmsConnector.Send(CxHsmsMessage.CtrlMsg_LinktestRsp());
                            return;
                    }


                    if (myMsg.header.StreamId == 1 && myMsg.header.FunctionId == 3)
                    {

                        var myList = myMsg.rootNode as CxSecsIINodeList;
                        if (myList == null) throw new Exception("Wrong SECS format");
                        var mySvid = myList.FirstOrDefault() as CxSecsIINodeUInt16;
                        if (mySvid == null) throw new Exception("Wrong SECS format");
                        Console.WriteLine("SVID={0}", mySvid.Data[0]);


                        var msg = new CxHsmsMessage();
                        msg.header.StreamId = 1;
                        msg.header.FunctionId = 4;
                        var list = new CxSecsIINodeList();
                        var signal = new CxSecsIINodeFloat64();
                        signal.Data.Add(1.2);
                        list.Data.Add(signal);
                        msg.rootNode = list;

                        hsmsConnector.Send(msg);
                    }

                };




                hsmsConnector.IsActively = false;
                hsmsConnector.LocalUri = CtkNetUtil.ToUri("127.0.0.1", 5000);
                hsmsConnector.RemoteUri = CtkNetUtil.ToUri("127.0.0.1", 5001);
                for (int idx = 0; true; idx++)
                {
                    try
                    {
                        hsmsConnector.ConnectTry();
                        hsmsConnector.ReceiveLoop();
                    }
                    catch (Exception ex) { System.Diagnostics.Debug.WriteLine(ex.StackTrace); }
                }

            }
        }

        public static void HsmsConnectorTestActive()
        {
            using (var hsmsConnector = new CxHsmsConnector())
            {
                hsmsConnector.EhReceiveData += delegate (Object sen, CxHsmsConnectorRcvDataEventArg ea)
                {

                    var myMsg = ea.msg;


                    System.Diagnostics.Debug.WriteLine("S{0}F{1}", myMsg.header.StreamId, myMsg.header.FunctionId);
                    System.Diagnostics.Debug.WriteLine("SType= {0}", myMsg.header.SType);

                    switch (myMsg.header.SType)
                    {
                        case 1:
                            hsmsConnector.Send(CxHsmsMessage.CtrlMsg_SelectRsp(0));
                            return;
                        case 5:
                            hsmsConnector.Send(CxHsmsMessage.CtrlMsg_LinktestRsp());
                            return;
                    }

                    if (myMsg.header.StreamId == 1 && myMsg.header.FunctionId == 3)
                    {

                        var myList = myMsg.rootNode as CxSecsIINodeList;
                        if (myList == null) throw new Exception("Wrong SECS format");
                        var mySvid = myList.FirstOrDefault() as CxSecsIINodeUInt16;
                        if (mySvid == null) throw new Exception("Wrong SECS format");
                        Console.WriteLine("SVID={0}", mySvid.Data[0]);





                        var msg = new CxHsmsMessage();
                        msg.header.StreamId = 1;
                        msg.header.FunctionId = 4;
                        var list = new CxSecsIINodeList();
                        var signal = new CxSecsIINodeFloat64();
                        signal.Data.Add(1.2);
                        list.Data.Add(signal);
                        msg.rootNode = list;

                        hsmsConnector.Send(msg);
                    }

                };




                hsmsConnector.IsActively = true;
                hsmsConnector.LocalUri = CtkNetUtil.ToUri("127.0.0.1", 5000);
                //hsmsConnector.Remote = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 5001);
                for (int idx = 0; true; idx++)
                {
                    try
                    {
                        hsmsConnector.ConnectTry();
                        hsmsConnector.Send(CxHsmsMessage.CtrlMsg_SelectReq());
                        hsmsConnector.ReceiveLoop();
                    }
                    catch (Exception ex) { System.Diagnostics.Debug.WriteLine(ex.StackTrace); }
                }

            }




        }

    }
}
